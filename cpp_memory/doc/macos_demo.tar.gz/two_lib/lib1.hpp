#ifndef __lib1_hpp
#define __lib1_hpp

namespace lib1 {

void foo();

}   // namespace lib1

#endif
