#ifndef _CONVERT_MANAGER_H
#define _CONVERT_MANAGER_H

#include <config.h>
#include <linux/videodev2.h>
#include <v4l2.h>
//#include <opencv2/opencv.hpp>
#include "opencv2/highgui/highgui.hpp"
#include "opencv2/imgproc/imgproc.hpp"

using namespace cv;

int isSupportRgb2Rgb(int iPixelFormatIn, int iPixelFormatOut);
int Mjpeg2RgbConvert(PT_VideoBuf ptVideoBufIn, Mat &img);
unsigned int Yuv2RgbConvert(PT_VideoBuf ptVideoBufIn, Mat &img);
int ConvertExit(PT_VideoBuf ptVideoBufOut);

#endif /* _CONVERT_MANAGER_H */
