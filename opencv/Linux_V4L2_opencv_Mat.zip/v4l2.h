#ifndef _VIDEO_MANAGER_H
#define _VIDEO_MANAGER_H

#include <config.h>
#include <pic_operation.h>
#include <linux/videodev2.h>
#include <opencv2/opencv.hpp>

#define NB_BUFFER 2

using namespace cv;

class DispOpr;
#define MAX_DEVICE_DRIVER_NAME 80

struct VideoDevice {
public:
 	int iFd;
	int iPixelFormat;
	int iWidth;
	int iHeight;
	int iBpp;
	bool isOpened;

	int iVideoBufCnt;
	int iVideoBufMaxLen;
	int iVideoBufCurIndex;
	unsigned char *pucVideoBuf[NB_BUFFER];
	char deviceName[MAX_DEVICE_DRIVER_NAME];

public:
	VideoDevice(int index);
	~VideoDevice();
	int isSupportThisFormat(int iPixelFormat);
	int V4l2InitDevice(char *strDevName);
	int V4l2ExitDevice();
	int V4l2GetFrameForStreaming(PT_VideoBuf ptVideoBuf);
	int V4l2PutFrameForStreaming(PT_VideoBuf ptVideoBuf);
	int V4l2StartDevice();
	int V4l2StopDevice();
	int V4l2GetFormat();
	int operator>>(Mat &img);
};
 
#endif /* _VIDEO_MANAGER_H */

