#ifndef _CONFIG_H
#define _CONFIG_H

#include <stdio.h>
#include<pic_operation.h>


//��ȡ��ͼƬ��С
#define PIC_WIGHT   640
#define PIC_HIGHT   480
#define PIC_SIZE   (PIC_WIGHT*PIC_HIGHT*3)


//JPEG��汾
#define JPEG_LIB_VERSION  62

//������Ϣ
#define DEBUG 0

#if DEBUG
#define DBG_PRINTF printf	
#else
#define DBG_PRINTF(...)
#endif

//fa@NanoPi3:~/14th_v4l2$
#endif /* _CONFIG_H */
