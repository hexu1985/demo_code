#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <poll.h>
#include <sys/ioctl.h>
#include <string.h>
#include <unistd.h>
#include <linux/videodev2.h>
#include <v4l2.h>
 #include <stdlib.h>
#include "color.h"
#include <convert.h>

#include <config.h>

VideoDevice::VideoDevice(int index)
{
	int error;
	
	sprintf(deviceName, "/dev/video%d", index);
	error = V4l2InitDevice(deviceName);
	if(error)
	{
		DBG_PRINTF("VideoDeviceInit for %s error!\n", deviceName);	
		isOpened = false;
	}
	
	isOpened = true;
}

VideoDevice::~VideoDevice()
{
	V4l2ExitDevice();
}

int VideoDevice::isSupportThisFormat(int iPixelFormat)
{
	if(iPixelFormat == V4L2_PIX_FMT_MJPEG)
	{
		printf("SupportThisFormat:%s\n","MJPEG"); 	 
		iPixelFormat =0;
		return 1;
	}

#if 0	
	if(iPixelFormat == V4L2_PIX_FMT_YUYV)
	{
		printf("SupportThisFormat:%s\n","YUYV"); 	 
		iPixelFormat =16;
		initLut();
		return 1;
	}
#endif	
	if(iPixelFormat == V4L2_PIX_FMT_RGB565)
	{
		printf("SupportThisFormat:%s\n","RGB565"); 	 
		iPixelFormat =16;
		return 1;
	}

	if(iPixelFormat == V4L2_PIX_FMT_BGR24)
	{
		printf("SupportThisFormat:%s\n","BGR24"); 	 
		iPixelFormat =24;
		return 1;
	}

	if(iPixelFormat == V4L2_PIX_FMT_RGB24)
	{
		printf("SupportThisFormat:%s\n","RGB24"); 	 
		iPixelFormat =24;
		return 1;
	}

	return 0;
}
   
int VideoDevice::V4l2InitDevice(char *strDevName)
{
	int i;
	int fd;
	int iError;
	struct v4l2_capability tV4l2Cap;
	struct v4l2_fmtdesc tFmtDesc;
	struct v4l2_format tV4l2Fmt;
	struct v4l2_requestbuffers tV4l2ReqBuffs;
	struct v4l2_buffer tV4l2Buf;
		
	fd = open(strDevName, O_RDWR);
	if(fd  < 0)
	{
		DBG_PRINTF("can not open %s\n",strDevName);
		return -1;		
	}
	iFd = fd ;
	
	memset(&tV4l2Cap, 0, sizeof(struct v4l2_capability));
	iError = ioctl(iFd, VIDIOC_QUERYCAP, &tV4l2Cap);
	if (iError) {
		DBG_PRINTF("Error opening device %s: unable to query device.\n", strDevName);
		goto err_exit;
	}

	if(!(tV4l2Cap.capabilities & V4L2_CAP_VIDEO_CAPTURE))
	{
		DBG_PRINTF("%s is not a video capture device\n ", strDevName);
		goto err_exit;
	}

	if (tV4l2Cap.capabilities & V4L2_CAP_STREAMING) {
	    DBG_PRINTF("%s supports streaming i/o\n", strDevName);
	}
	
	if (tV4l2Cap.capabilities & V4L2_CAP_READWRITE) {
	    DBG_PRINTF("%s support read i/o\n",strDevName);
	}

	memset(&tFmtDesc, 0, sizeof(struct v4l2_fmtdesc));
	tFmtDesc.index = 0;
	tFmtDesc.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
	while ((iError= ioctl(iFd, VIDIOC_ENUM_FMT, &tFmtDesc)) == 0) {
		if(isSupportThisFormat(tFmtDesc.pixelformat))
		{
			iPixelFormat = tFmtDesc.pixelformat;
			break;
		}
		tFmtDesc.index++;
	}
	
	if(!iPixelFormat)
	{
		DBG_PRINTF("can not support the format of this device\n ");
		goto err_exit;
	}

	/* set format in */
	memset(&tV4l2Fmt, 0, sizeof(struct v4l2_format));
	tV4l2Fmt.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
	tV4l2Fmt.fmt.pix.pixelformat = iPixelFormat;
	tV4l2Fmt.fmt.pix.width = 640;
	tV4l2Fmt.fmt.pix.height =480;
	tV4l2Fmt.fmt.pix.field = V4L2_FIELD_ANY;

	/* ��������������޷�֧��ĳЩ����(����ֱ���)��
	  * ���������Щ���������ҷ��ظ�Ӧ�ó��� 
	  */
	iError = ioctl(iFd, VIDIOC_S_FMT, &tV4l2Fmt);
	if (iError) {
		DBG_PRINTF("Unable to set format\n");
		goto err_exit;
	}
    	iWidth  = tV4l2Fmt.fmt.pix.width;
    	iHeight = tV4l2Fmt.fmt.pix.height;
    	DBG_PRINTF("VideoDevice width = %d,  height = %d\n",iWidth, iHeight);
    	//VideoDevice width = 320,  height = 240

	/* request buffers */
	memset(&tV4l2ReqBuffs, 0, sizeof(struct v4l2_requestbuffers));
	tV4l2ReqBuffs.count = NB_BUFFER;
	tV4l2ReqBuffs.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
	tV4l2ReqBuffs.memory = V4L2_MEMORY_MMAP;

	iError = ioctl(iFd, VIDIOC_REQBUFS, &tV4l2ReqBuffs);
	if (iError) {
		DBG_PRINTF("Unable to allocate buffers.\n");
		goto err_exit;
	}
	iVideoBufCnt = tV4l2ReqBuffs.count;

	if(tV4l2Cap.capabilities & V4L2_CAP_STREAMING)
	{
   		 /* map the buffers */
		for (i = 0; i < iVideoBufCnt; i++) 
		{
			memset(&tV4l2Buf, 0, sizeof(struct v4l2_buffer));
			tV4l2Buf.index = i;
			tV4l2Buf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
			tV4l2Buf.memory = V4L2_MEMORY_MMAP;
			iError = ioctl(iFd, VIDIOC_QUERYBUF, &tV4l2Buf);
			if (iError) 
			{
				DBG_PRINTF("Unable to query buffer.\n");
				goto err_exit;
			}
			iVideoBufMaxLen = tV4l2Buf.length;
			pucVideoBuf[i] = (unsigned char*)mmap(0 /* start anywhere */ ,
					  tV4l2Buf.length, PROT_READ, MAP_SHARED, iFd,
					  tV4l2Buf.m.offset);
			if (pucVideoBuf[i] == MAP_FAILED)
                    {
				DBG_PRINTF("Unable to map buffer.\n");
				goto err_exit;
			}			
		}
		
		 /* Queue the buffers. */
		for (i = 0; i < iVideoBufCnt; i++)
		{
			memset(&tV4l2Buf, 0, sizeof(struct v4l2_buffer));
			tV4l2Buf.index = i;
			tV4l2Buf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
			tV4l2Buf.memory = V4L2_MEMORY_MMAP;
			iError = ioctl(iFd, VIDIOC_QBUF, &tV4l2Buf);
			if (iError ) {
			   	DBG_PRINTF("%d  Unable to queue buffer.  fd = %d  i= %d \n",__LINE__,  iFd, i);
				goto err_exit;
			}
		}
	}	
	else if(tV4l2Cap.capabilities & V4L2_CAP_READWRITE)
	{        
		/* read(fd, buf, size) */
		iVideoBufCnt = 1;
		/* �������������֧�ֵĸ�ʽ�һ���������ֻ��Ҫ4�ֽ� */
		iVideoBufMaxLen = iWidth * iHeight * 4;
		pucVideoBuf[0] =(unsigned char*)malloc(iVideoBufMaxLen);
	}
	return 0;

err_exit:
	close(iFd);	
	return -1;
}

int VideoDevice::V4l2ExitDevice()
{
	int i;
	for(i = 0; i < iVideoBufCnt; i++)
	{
		if(pucVideoBuf[i])
		{
			munmap(pucVideoBuf[i], iVideoBufMaxLen);
			pucVideoBuf[i] =NULL;
		}
	}
	
	close(iFd);
	return 0;
}	

int VideoDevice::V4l2GetFrameForStreaming(PT_VideoBuf ptVideoBuf)
{
	struct pollfd tFds[1];	
	int iRet;
	struct v4l2_buffer tV4l2Buf;
	
	/* poll */
	tFds[0].fd 	= iFd;
	tFds[0].events = POLLIN;
	
	iRet = poll(tFds, 1,-1);  //-1��Զ�ȴ�
	if(iRet <=0)
	{
		DBG_PRINTF("poll error!\n");
		return -1;
	}
	
	/* VIDIOC_DQBUF */
	memset(&tV4l2Buf, 0, sizeof(struct v4l2_buffer));
	tV4l2Buf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
	tV4l2Buf.memory = V4L2_MEMORY_MMAP;
	iRet = ioctl(iFd, VIDIOC_DQBUF, &tV4l2Buf);
	if (iRet < 0) {
		DBG_PRINTF("Unable to dequeue buffer.\n");
		return -1;
	}
	iVideoBufCurIndex= tV4l2Buf.index;


	ptVideoBuf->tPixelDatas.iTotalBytes	= tV4l2Buf.bytesused ;
	ptVideoBuf->tPixelDatas.aucPixelDatas	= pucVideoBuf[tV4l2Buf.index];
	
	return 0;
}


int VideoDevice::V4l2PutFrameForStreaming(PT_VideoBuf ptVideoBuf)
{
	struct v4l2_buffer tV4l2Buf;
	int iError;
	
	/* VIDIOC_QBUF */
	memset(&tV4l2Buf, 0, sizeof(struct v4l2_buffer));
	tV4l2Buf.index 	= iVideoBufCurIndex;
	tV4l2Buf.type 		= V4L2_BUF_TYPE_VIDEO_CAPTURE;
	tV4l2Buf.memory 	= V4L2_MEMORY_MMAP;
	iError = ioctl(iFd, VIDIOC_QBUF, &tV4l2Buf);
	if (iError) 
	{
		DBG_PRINTF("%d Unable to queue buffer.\n", __LINE__);
		return -1;
	}
	return 0;


}

int VideoDevice::V4l2StartDevice()
{
	int iType = V4L2_BUF_TYPE_VIDEO_CAPTURE;
	int iError;

	iError = ioctl(iFd, VIDIOC_STREAMON, &iType);
	if (iError) 
	{
		DBG_PRINTF("Unable to start capture.\n");
		return -1;
	}
	return 0;
  }

int VideoDevice::V4l2StopDevice()
{
	int iType = V4L2_BUF_TYPE_VIDEO_CAPTURE;
	int iError;

	iError = ioctl(iFd, VIDIOC_STREAMOFF, &iType);
	if (iError) 
	{
		DBG_PRINTF("Unable to stop capture.\n");
		return -1;
	}
	return 0;
  }

int VideoDevice::V4l2GetFormat()
{
	return iPixelFormat;
}

int VideoDevice::operator>>(Mat &img)
{
	int iError =0 ;
	T_VideoBuf tVideoBuf;	
	
	/* ��������ͷ����,����ͷ�����ݸ�ʽΪJPEG */
	if(V4l2GetFrameForStreaming(&tVideoBuf))
	{
		DBG_PRINTF("GetFrame for error!\n");
		return iError;
	}

	if(iPixelFormat == V4L2_PIX_FMT_MJPEG)
	{
		/* ��JPEGͼ��תΪBBGGRRͼ�����ݣ��洢��Mat�� */		
		iError = Mjpeg2RgbConvert(&tVideoBuf, img);
		if(iError)
		{
			DBG_PRINTF("Convert error!\n");
			return iError;
		}	
		iError = V4l2PutFrameForStreaming(&tVideoBuf);
		if(iError)
		{
			DBG_PRINTF("V4l2PutFrameForStreaming error!\n");
			return iError;
		}
	}	
	else if(iPixelFormat == V4L2_PIX_FMT_YUYV)
	{
		/* YUYV ==> 0xBBGGRR */
		iError = Yuv2RgbConvert(&tVideoBuf, img);
		if(iError)
		{
			DBG_PRINTF("Convert error!\n");
			return iError;
		}	
	}	
		
	return iError;
}
