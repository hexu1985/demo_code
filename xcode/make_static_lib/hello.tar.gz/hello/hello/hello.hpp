//
//  hello.hpp
//  hello
//
//  Created by 何旭 on 2018/11/5.
//  Copyright © 2018年 何旭. All rights reserved.
//

#ifndef hello_
#define hello_

/* The classes below are exported */
#pragma GCC visibility push(default)

extern "C" {
    int print_hello();
}

#pragma GCC visibility pop
#endif
