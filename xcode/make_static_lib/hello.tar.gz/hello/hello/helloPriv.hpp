//
//  helloPriv.hpp
//  hello
//
//  Created by 何旭 on 2018/11/5.
//  Copyright © 2018年 何旭. All rights reserved.
//

/* The classes below are not exported */
#pragma GCC visibility push(hidden)

void print_hello(int);

#pragma GCC visibility pop
