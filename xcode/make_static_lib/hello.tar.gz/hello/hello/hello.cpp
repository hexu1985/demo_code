//
//  hello.cpp
//  hello
//
//  Created by 何旭 on 2018/11/5.
//  Copyright © 2018年 何旭. All rights reserved.
//

#include <iostream>
#include <assert.h>
#include "hello.hpp"
#include "helloPriv.hpp"

using namespace std;

extern "C" {
    
    int print_hello()
    {
        cout << "hello world!" << endl;
#ifndef NDEBUG
        assert(false);
#endif
        return 1;
    }
    
}

void print_hello(int)
{
    cout << "int hello world!" << endl;
}

