//
//  hello.h
//  test
//
//  Created by 何旭 on 2018/11/5.
//  Copyright © 2018年 何旭. All rights reserved.
//

#ifndef hello_h
#define hello_h

extern "C" int print_hello();

#endif /* hello_h */
