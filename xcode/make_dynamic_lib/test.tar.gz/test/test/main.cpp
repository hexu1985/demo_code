//
//  main.cpp
//  test
//
//  Created by 何旭 on 2018/11/5.
//  Copyright © 2018年 何旭. All rights reserved.
//

#include "hello.h"

int main()
{
    print_hello();
    return 0;
}

