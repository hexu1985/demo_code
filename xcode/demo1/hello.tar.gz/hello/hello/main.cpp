//
//  main.cpp
//  hello
//
//  Created by 何旭 on 2018/11/5.
//  Copyright © 2018年 何旭. All rights reserved.
//

#include <iostream>

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
