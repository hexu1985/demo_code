//
//  main.cpp
//  demo1
//
//  Created by sensetime on 2018/11/8.
//  Copyright © 2018年 sensetime. All rights reserved.
//

#include <iostream>

unsigned int target_function(unsigned int n);

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "entry an int!\n";
    int a;
    std::cin >> a;
    return target_function(a);
}

unsigned int target_function(unsigned int n)
{
    unsigned int mod = n % 4;
    unsigned int result = 0;
    if (mod == 0) result = (n | 0xBAAAD0BF) * (2 ^ n);
        else if (mod == 1) result = (n & 0xBAAAD0BF) * (3 + n);
            else if (mod == 2) result = (n ^ 0xBAAAD0BF) * (4 | n);
                else result = (n + 0xBAAAD0BF) * (5 & n);
                    return result;
}
