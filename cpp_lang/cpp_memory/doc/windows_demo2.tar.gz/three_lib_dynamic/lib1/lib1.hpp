#ifndef __lib1_hpp
#define __lib1_hpp

namespace lib1 {

_declspec(dllexport)
void foo();

}   // namespace lib1

#endif
